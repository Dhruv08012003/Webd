import React from 'react'

const Footer = () => {
  return (
      <div>
      <h4>@Copyright: KIeT MCA</h4>
      </div>
  )
}

export default Footer